const adminData = {
  categories: [
    {
      name: 'Frozen Cleansift',
      products: [
        {
          title: 'Emergency',
          description: 'Korte omschrijving',
          brand: 'TopOrganic',
          image: '',
          variants: [
            { amount: '10 gram', price: '25' },
            { amount: '20 gram', price: '45' }
          ]
        }
      ]
    },
    { name: 'Static Cleansift', products: [] }
  ]
};

function createVariantRow(variant = { amount: '', price: '' }) {
  const row = document.createElement('div');
  row.className = 'variant-item';
  row.innerHTML = `
    <input type="text" placeholder="Hoeveelheid, bv. 10 gram" value="${variant.amount}">
    <input type="text" placeholder="Prijs" value="${variant.price}">
    <button type="button" class="danger-btn">Verwijder</button>
  `;
  row.querySelector('button').addEventListener('click', () => row.remove());
  return row;
}

function createProductEditor(product = { title:'', description:'', brand:'', image:'', variants:[{ amount:'', price:'' }] }) {
  const wrap = document.createElement('div');
  wrap.className = 'product-editor';
  wrap.innerHTML = `
    <div class="grid-2">
      <label class="field"><input type="text" placeholder="Productnaam" value="${product.title}"></label>
      <label class="field"><input type="text" placeholder="Merk / Farm" value="${product.brand}"></label>
    </div>
    <div class="field" style="margin-top:10px"><textarea placeholder="Beschrijving">${product.description}</textarea></div>
    <div class="field" style="margin-top:10px"><input type="text" placeholder="Afbeelding URL" value="${product.image}"></div>
    <div class="variant-list"></div>
    <div class="actions">
      <button type="button" class="ghost-btn add-variant">+ Hoeveelheid toevoegen</button>
      <button type="button" class="danger-btn remove-product">Product verwijderen</button>
    </div>
  `;
  const list = wrap.querySelector('.variant-list');
  (product.variants || []).forEach(v => list.appendChild(createVariantRow(v)));
  wrap.querySelector('.add-variant').addEventListener('click', () => list.appendChild(createVariantRow()));
  wrap.querySelector('.remove-product').addEventListener('click', () => wrap.remove());
  return wrap;
}

function renderAdmin() {
  const root = document.getElementById('categoryList');
  root.innerHTML = '';
  adminData.categories.forEach(category => {
    const block = document.createElement('section');
    block.className = 'category-block';
    block.innerHTML = `
      <div class="category-header">
        <h2 class="category-title">${category.name}</h2>
        <button type="button" class="danger-btn remove-category">Verwijder categorie</button>
      </div>
      <div class="products"></div>
      <div class="actions">
        <button type="button" class="ghost-btn add-product">+ Product toevoegen</button>
      </div>
    `;
    const productsWrap = block.querySelector('.products');
    if (category.products.length) {
      category.products.forEach(product => productsWrap.appendChild(createProductEditor(product)));
    } else {
      const p = document.createElement('p');
      p.className = 'note';
      p.textContent = 'Nog geen producten in deze categorie.';
      productsWrap.appendChild(p);
    }
    block.querySelector('.add-product').addEventListener('click', () => {
      const note = productsWrap.querySelector('.note');
      if (note) note.remove();
      productsWrap.appendChild(createProductEditor());
    });
    block.querySelector('.remove-category').addEventListener('click', () => block.remove());
    root.appendChild(block);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderAdmin();
  document.getElementById('addCategory').addEventListener('click', () => {
    const name = prompt('Naam van nieuwe categorie');
    if (!name) return;
    adminData.categories.push({ name, products: [] });
    renderAdmin();
  });
  document.getElementById('saveButton').addEventListener('click', () => {
    alert('Demo-opslag: koppel dit aan jouw backend, JSON of database.');
  });
});
