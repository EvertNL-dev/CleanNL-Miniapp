# CleanNL Mini App

GitHub-klare starter voor een Telegram Mini App storefront plus een simpel admin paneel.

## Bestanden
- `miniapp.html` — storefront/mobile shop UI
- `admin.html` — admin paneel om categorieën, producten en meerdere hoeveelheden toe te voegen
- `styles.css` — gedeelde styling
- `app.js` — storefront logica
- `admin.js` — admin logica

## Werking
- Data wordt tijdelijk in het geheugen geladen vanuit voorbeelddata.
- In productie kun je dit koppelen aan JSON, Firebase, Supabase of je bot-backend.
- Producten ondersteunen varianten zoals 10 gram, 20 gram en 50 gram met eigen prijzen.

## GitHub Pages
1. Upload deze map naar een GitHub repository.
2. Zet GitHub Pages aan op de branch.
3. Gebruik `miniapp.html` als storefront en `admin.html` als beheerpagina.
