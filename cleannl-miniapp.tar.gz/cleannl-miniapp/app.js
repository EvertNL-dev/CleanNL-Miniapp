const storeData = {
  user: { name: 'Evert', initials: 'E' },
  categories: ['Frozen Cleansift', 'Static Cleansift', 'Premium'],
  farms: ['TopOrganic', 'Unbrand', 'CleanFarm'],
  products: [
    {
      id: 1,
      title: 'Emergency',
      brand: 'TopOrganic',
      category: 'Frozen Cleansift',
      image: 'https://images.unsplash.com/photo-1506617420156-8e4536971650?auto=format&fit=crop&w=900&q=80',
      featured: true,
      variants: [
        { amount: '10 gram', price: 25 },
        { amount: '20 gram', price: 45 },
        { amount: '50 gram', price: 100 }
      ]
    },
    {
      id: 2,
      title: 'Grappe Gasoline',
      brand: 'Unbrand',
      category: 'Frozen Cleansift',
      image: 'https://images.unsplash.com/photo-1473773508845-188df298d2d1?auto=format&fit=crop&w=900&q=80',
      featured: true,
      variants: [
        { amount: '10 gram', price: 28 },
        { amount: '20 gram', price: 50 },
        { amount: '50 gram', price: 110 }
      ]
    },
    {
      id: 3,
      title: 'Handstatic Premium',
      brand: 'TopOrganic',
      category: 'Premium',
      image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80',
      featured: false,
      variants: [
        { amount: '10 gram', price: 30 },
        { amount: '20 gram', price: 55 },
        { amount: '50 gram', price: 125 }
      ]
    }
  ]
};

function formatPrice(v) { return '€' + Number(v).toFixed(2).replace('.00', ''); }

function renderProducts(products) {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  products.forEach(product => {
    const card = document.createElement('article');
    card.className = 'product-card';
    const defaultVariant = product.variants[0];
    card.innerHTML = `
      <img src="${product.image}" alt="${product.title}" loading="lazy">
      <div class="product-body">
        <span class="badge">✦ ${product.brand}</span>
        <h3 class="product-title">${product.title}</h3>
        <div class="variant-row">
          ${product.variants.map((v, i) => `<button class="variant-btn ${i===0?'active':''}" data-price="${v.price}">${v.amount}</button>`).join('')}
        </div>
        <div class="price-row">
          <div>
            <div class="meta">${product.category}</div>
            <div class="price">${formatPrice(defaultVariant.price)}</div>
          </div>
          <button class="icon-btn" aria-label="Toevoegen">♡</button>
        </div>
      </div>
    `;
    const priceEl = card.querySelector('.price');
    card.querySelectorAll('.variant-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        card.querySelectorAll('.variant-btn').forEach(x => x.classList.remove('active'));
        btn.classList.add('active');
        priceEl.textContent = formatPrice(btn.dataset.price);
      });
    });
    grid.appendChild(card);
  });
  document.getElementById('productCount').textContent = `${products.length} products`;
}

function initStore() {
  const categorySelect = document.getElementById('categorySelect');
  const farmSelect = document.getElementById('farmSelect');
  const userName = document.getElementById('userName');
  const userInitials = document.getElementById('userInitials');
  userName.textContent = storeData.user.name;
  userInitials.textContent = storeData.user.initials;
  storeData.categories.forEach(c => categorySelect.insertAdjacentHTML('beforeend', `<option value="${c}">${c}</option>`));
  storeData.farms.forEach(f => farmSelect.insertAdjacentHTML('beforeend', `<option value="${f}">${f}</option>`));

  function filter() {
    const c = categorySelect.value;
    const f = farmSelect.value;
    const filtered = storeData.products.filter(p => (!c || p.category === c) && (!f || p.brand === f));
    renderProducts(filtered);
  }

  categorySelect.addEventListener('change', filter);
  farmSelect.addEventListener('change', filter);
  renderProducts(storeData.products);
}

document.addEventListener('DOMContentLoaded', initStore);
