require("dotenv").config();
const { Telegraf, Markup } = require("telegraf");

const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBAPP_URL = process.env.WEBAPP_URL; // bv. https://jouwuser.github.io/keuken-webshop/webapp/

if (!BOT_TOKEN) {
  console.error("BOT_TOKEN ontbreekt. Zet 'm in je .env bestand.");
  process.exit(1);
}
if (!WEBAPP_URL) {
  console.error("WEBAPP_URL ontbreekt. Zet 'm in je .env bestand (moet https zijn).");
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

bot.start((ctx) => {
  ctx.reply(
    "Welkom! Bekijk hieronder ons volledige assortiment met prijzen en foto's.",
    Markup.inlineKeyboard([
      Markup.button.webApp("🛒 Bekijk producten", WEBAPP_URL)
    ])
  );
});

bot.command("shop", (ctx) => {
  ctx.reply(
    "Open de winkel:",
    Markup.inlineKeyboard([
      Markup.button.webApp("🛒 Bekijk producten", WEBAPP_URL)
    ])
  );
});

// Ook een keyboard-knop onderaan het scherm (blijft zichtbaar)
bot.command("menu", (ctx) => {
  ctx.reply(
    "Menu geopend.",
    Markup.keyboard([
      Markup.button.webApp("🛒 Bekijk producten", WEBAPP_URL)
    ]).resize()
  );
});

bot.catch((err, ctx) => {
  console.error(`Fout bij update ${ctx.updateType}:`, err);
});

bot.launch().then(() => {
  console.log("Bot draait via polling...");
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
