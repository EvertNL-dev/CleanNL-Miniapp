// ---- Config / session (token blijft alleen lokaal in de browser) ----
let session = JSON.parse(localStorage.getItem("gh_admin_session") || "null");
let productsData = { categories: [], products: [] };
let currentSha = null; // GitHub file sha, nodig om te kunnen updaten
let editingProductId = null;

const PRODUCTS_PATH = "webapp/products.json"; // pad in de repo

const loginScreen = document.getElementById("loginScreen");
const adminScreen = document.getElementById("adminScreen");
const statusMsg = document.getElementById("statusMsg");

function ghApiBase() {
  return `https://api.github.com/repos/${session.owner}/${session.repo}/contents/${PRODUCTS_PATH}`;
}

function ghHeaders() {
  return {
    "Authorization": `Bearer ${session.token}`,
    "Accept": "application/vnd.github+json"
  };
}

function showStatus(text, isError = false) {
  statusMsg.textContent = text;
  statusMsg.classList.remove("hidden", "error");
  if (isError) statusMsg.classList.add("error");
  setTimeout(() => statusMsg.classList.add("hidden"), 4000);
}

// ---- Login ----
document.getElementById("loginBtn").onclick = async () => {
  const owner = document.getElementById("ghOwner").value.trim();
  const repo = document.getElementById("ghRepo").value.trim();
  const branch = document.getElementById("ghBranch").value.trim() || "main";
  const token = document.getElementById("ghToken").value.trim();
  const errorEl = document.getElementById("loginError");

  if (!owner || !repo || !token) {
    errorEl.textContent = "Vul alle velden in.";
    errorEl.classList.remove("hidden");
    return;
  }

  session = { owner, repo, branch, token };

  try {
    const res = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${PRODUCTS_PATH}?ref=${branch}`,
      { headers: ghHeaders() }
    );
    if (!res.ok) throw new Error(`GitHub gaf status ${res.status} terug. Controleer repo-naam, branch en token-rechten.`);

    localStorage.setItem("gh_admin_session", JSON.stringify(session));
    errorEl.classList.add("hidden");
    await loadProducts();
    loginScreen.classList.add("hidden");
    adminScreen.classList.remove("hidden");
  } catch (err) {
    errorEl.textContent = err.message;
    errorEl.classList.remove("hidden");
  }
};

document.getElementById("logoutBtn").onclick = () => {
  localStorage.removeItem("gh_admin_session");
  session = null;
  location.reload();
};

// ---- Load products.json from GitHub ----
async function loadProducts() {
  const res = await fetch(`${ghApiBase()}?ref=${session.branch}`, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Kon products.json niet laden van GitHub.");
  const data = await res.json();
  currentSha = data.sha;
  const decoded = decodeURIComponent(escape(atob(data.content)));
  productsData = JSON.parse(decoded);
  if (!productsData.categories) productsData.categories = [];
  if (!productsData.products) productsData.products = [];
  renderTable();
}

// ---- Save products.json to GitHub (commit) ----
async function saveProducts(commitMessage) {
  const content = JSON.stringify(productsData, null, 2);
  const encoded = btoa(unescape(encodeURIComponent(content)));

  const res = await fetch(ghApiBase(), {
    method: "PUT",
    headers: { ...ghHeaders(), "Content-Type": "application/json" },
    body: JSON.stringify({
      message: commitMessage,
      content: encoded,
      sha: currentSha,
      branch: session.branch
    })
  });

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(errBody.message || `GitHub gaf status ${res.status} terug bij opslaan.`);
  }

  const result = await res.json();
  currentSha = result.content.sha; // sha bijwerken voor volgende save
}

// ---- Render product table ----
function renderTable() {
  const tbody = document.getElementById("productTableBody");
  tbody.innerHTML = "";
  productsData.products.forEach(p => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><img src="${p.images?.[0] || ""}" alt=""></td>
      <td>${p.name}</td>
      <td>${p.category || "-"}</td>
      <td>${p.price != null ? p.price.toFixed(2) + " " + (p.currency || "EUR") : "-"}</td>
      <td>${p.active !== false ? "Ja" : "Nee"}</td>
      <td><button class="btn-secondary small" data-id="${p.id}">Bewerken</button></td>
    `;
    tr.querySelector("button").onclick = () => openEdit(p.id);
    tbody.appendChild(tr);
  });
}

// ---- Edit modal ----
const editModal = document.getElementById("editModal");
const quantityRowsEl = document.getElementById("quantityRows");

function addQuantityRow(label = "", amount = "", price = "") {
  const row = document.createElement("div");
  row.className = "quantity-row-item";
  row.innerHTML = `
    <input placeholder="Label (bijv. 2 stuks)" class="q_label" value="${label}">
    <input placeholder="Aantal" type="number" class="q_amount" value="${amount}" style="width:70px">
    <input placeholder="Prijs" type="number" step="0.01" class="q_price" value="${price}" style="width:80px">
    <button class="btn-secondary small remove-qty">×</button>
  `;
  row.querySelector(".remove-qty").onclick = () => row.remove();
  quantityRowsEl.appendChild(row);
}

document.getElementById("addQuantityBtn").onclick = () => addQuantityRow();

function openEdit(id) {
  editingProductId = id;
  const p = id ? productsData.products.find(x => x.id === id) : null;

  document.getElementById("editTitle").textContent = p ? "Product bewerken" : "Nieuw product";
  document.getElementById("f_name").value = p?.name || "";
  document.getElementById("f_category").value = p?.category || "";
  document.getElementById("f_price").value = p?.price ?? "";
  document.getElementById("f_currency").value = p?.currency || "EUR";
  document.getElementById("f_unit").value = p?.unit || "stuk";
  document.getElementById("f_description").value = p?.description || "";
  document.getElementById("f_images").value = (p?.images || []).join("\n");
  document.getElementById("f_videos").value = (p?.videos || []).join("\n");
  document.getElementById("f_active").checked = p?.active !== false;

  quantityRowsEl.innerHTML = "";
  (p?.quantities || []).forEach(q => addQuantityRow(q.label, q.amount, q.price));

  document.getElementById("deleteProductBtn").classList.toggle("hidden", !p);
  editModal.classList.remove("hidden");
}

document.getElementById("addProductBtn").onclick = () => openEdit(null);
document.getElementById("cancelEditBtn").onclick = () => editModal.classList.add("hidden");

document.getElementById("saveProductBtn").onclick = async () => {
  const name = document.getElementById("f_name").value.trim();
  if (!name) { alert("Naam is verplicht."); return; }

  const quantities = [...quantityRowsEl.querySelectorAll(".quantity-row-item")].map(row => ({
    label: row.querySelector(".q_label").value.trim(),
    amount: Number(row.querySelector(".q_amount").value) || 1,
    price: Number(row.querySelector(".q_price").value) || 0
  })).filter(q => q.label);

  const productObj = {
    id: editingProductId || "prod_" + Date.now(),
    name,
    category: document.getElementById("f_category").value.trim(),
    price: Number(document.getElementById("f_price").value) || 0,
    currency: document.getElementById("f_currency").value.trim() || "EUR",
    unit: document.getElementById("f_unit").value.trim() || "stuk",
    description: document.getElementById("f_description").value.trim(),
    images: document.getElementById("f_images").value.split("\n").map(s => s.trim()).filter(Boolean),
    videos: document.getElementById("f_videos").value.split("\n").map(s => s.trim()).filter(Boolean),
    quantities,
    active: document.getElementById("f_active").checked
  };

  if (editingProductId) {
    const idx = productsData.products.findIndex(x => x.id === editingProductId);
    productsData.products[idx] = productObj;
  } else {
    productsData.products.push(productObj);
  }

  // Nieuwe categorie automatisch toevoegen aan lijst
  if (productObj.category && !productsData.categories.includes(productObj.category)) {
    productsData.categories.push(productObj.category);
  }

  try {
    await saveProducts(`Update product: ${name}`);
    renderTable();
    editModal.classList.add("hidden");
    showStatus("Opgeslagen en gecommit naar GitHub.");
  } catch (err) {
    showStatus(err.message, true);
  }
};

document.getElementById("deleteProductBtn").onclick = async () => {
  if (!confirm("Weet je zeker dat je dit product wilt verwijderen?")) return;
  productsData.products = productsData.products.filter(x => x.id !== editingProductId);
  try {
    await saveProducts(`Delete product: ${editingProductId}`);
    renderTable();
    editModal.classList.add("hidden");
    showStatus("Product verwijderd.");
  } catch (err) {
    showStatus(err.message, true);
  }
};

// ---- Init: auto-login if session saved ----
(async function init() {
  if (session) {
    document.getElementById("ghOwner").value = session.owner;
    document.getElementById("ghRepo").value = session.repo;
    document.getElementById("ghBranch").value = session.branch;
    try {
      await loadProducts();
      loginScreen.classList.add("hidden");
      adminScreen.classList.remove("hidden");
    } catch (err) {
      // token invalid ok, blijf op login
    }
  }
})();
